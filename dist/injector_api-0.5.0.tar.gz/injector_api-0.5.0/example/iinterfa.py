class IExampleService:
    def do_something(self):
        pass

class Se:
     def do_something(self):
        pass
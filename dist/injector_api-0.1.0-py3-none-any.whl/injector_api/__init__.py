from .container import DependencyContainer, SINGLETON, TRANSIENT, SCOPED, container
from .loader import inject, load_modules_from_subdirectories
from .scopeMiddlware import ScopeMiddleware

__version__ = '1.0.0'